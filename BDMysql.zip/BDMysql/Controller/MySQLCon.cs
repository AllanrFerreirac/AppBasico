﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using BDMysql.Models;
using MySqlConnector;

namespace BDMysql.Controller
{
    public class MySQLCon
    {
        static string conn = @"server=db4free.net;port=3306;database=testesqlmobile;user id=abc1973;password=@bc321973;charset=utf8";

        public static List<Naosei> ListarNaosei()
        {
            List<Naosei> listanaosei = new List<Naosei>();
            string sql = "SELECT * FROM naosei";
            using (MySqlConnection con = new MySqlConnection(conn))
            {
                con.Open();
                using(MySqlCommand cmd = new MySqlCommand(sql, con))
                {
                    using(MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Naosei naosei = new Naosei()
                            {
                                id = reader.GetInt32(0),
                                titulo = reader.GetString(1),
                                descricao = reader.GetString(2),
                                cor = reader.GetString(3)
                            };
                            listanaosei.Add(naosei);
                        }
                    }
                }
                con.Close();
                return listanaosei;
            }
        }

        public static void InserirNaosei(string titulo, string descricao, string cor)
        {
            string sql = "INSERT INTO naosei(titulo,descricao,cor) VALUES (@titulo,@descricao,@cor)";
            using(MySqlConnection con = new MySqlConnection(conn))
            {
                con.Open();
                using(MySqlCommand cmd = new MySqlCommand(sql, con))
                {
                    cmd.Parameters.Add("@titulo", MySqlDbType.VarChar).Value = titulo;
                    cmd.Parameters.Add("@descricao", MySqlDbType.VarChar).Value = descricao;
                    cmd.Parameters.Add("@cor", MySqlDbType.VarChar).Value = cor;
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                }
                con.Close();
            }
        }

        public static void AtualizarNaosei(Naosei naosei)
        {
            string sql = "UPDATE naosei SET titulo=@titulo,descricao=@descricao, cor=@cor WHERE id=@id";
            try
            {
                using(MySqlConnection con = new MySqlConnection(conn))
                {
                    con.Open();
                    using(MySqlCommand cmd = new MySqlCommand(sql, con))
                    {
                        cmd.Parameters.Add("@titulo", MySqlDbType.VarChar).Value = naosei.titulo;
                        cmd.Parameters.Add("@descricao", MySqlDbType.VarChar).Value = naosei.descricao;
                        cmd.Parameters.Add("@cor", MySqlDbType.VarChar).Value = naosei.cor;
                        cmd.Parameters.Add("@id", MySqlDbType.Int32).Value = naosei.id;
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                    }
                    con.Close();
                }
            }
            catch (Exception ex)
            {

            }
        }

        public static void ExcluirNaosei(Naosei naosei)
        {
            string sql = "DELETE FROM naosei WHERE id=@id";
            using(MySqlConnection con = new MySqlConnection(conn))
            {
                con.Open();
                using(MySqlCommand cmd = new MySqlCommand(sql, con))
                {
                    cmd.Parameters.Add("@id", MySqlDbType.Int32).Value = naosei.id;
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                }
                con.Close();
            }
        }
    }
}
