﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BDMysql.Models;
using BDMysql.Controller;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BDMysql
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PageUpDel : ContentPage
    {
        public Naosei naosei;

        public PageUpDel()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            BindingContext = naosei;
        }

        private void btAtualizar_Clicked(object sender, EventArgs e)
        {
            MySQLCon.AtualizarNaosei(naosei);
            Navigation.PopAsync();
        }

        private void btApagar_Clicked(object sender, EventArgs e)
        {
            if (naosei.id != 0 )
            {
                MySQLCon.ExcluirNaosei(naosei);
                Navigation.PopAsync();
            }
        }
    }
}