﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using BDMysql.Controller;

namespace BDMysql
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PageCadastrar : ContentPage
    {
        public PageCadastrar()
        {
            InitializeComponent();
        }

        private void btCadastrar_Clicked(object sender, EventArgs e)
        {
            MySQLCon.InserirNaosei(txtTitulo.Text, txtDescricao.Text, txtCor.Text);
            DisplayAlert("Cadastro", "Nao sei cadastrada com sucesso!", "OK");
            Navigation.PushAsync(new PageListar());
        }
    }
}