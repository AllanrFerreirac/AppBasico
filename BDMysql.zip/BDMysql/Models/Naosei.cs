﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BDMysql.Models
{
    public class Naosei
    {
        public int id { get; set; }
        public string titulo { get; set; }
        public string descricao { get; set; }
        public string cor { get; set; }
    }
}
